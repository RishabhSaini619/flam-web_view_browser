package com.example.webviewbrowser

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import androidx.core.view.WindowCompat

class MainActivity : AppCompatActivity() {

    private lateinit var urlField: EditText
    private lateinit var searchButton: Button
    private lateinit var webViewField: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)

        webViewField = findViewById(R.id.web_view_field)
        urlField = findViewById<EditText>(R.id.url_field)
        searchButton = findViewById<Button>(R.id.src_btn)
        searchButton.setOnClickListener {
            loadURL()
        }

    }
    private fun loadURL() {
        val url = urlField.text.toString()
        webViewField.webViewClient = WebViewClient()

        webViewField.apply {
            loadUrl(url)
            settings.javaScriptEnabled = true
            settings.allowContentAccess =true
            settings.allowFileAccess = true

        }
    }
}